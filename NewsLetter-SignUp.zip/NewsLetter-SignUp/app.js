const express = require("express");
const bodyParser = require("body-parser");
const request = require("request");
const https = require("https");

const app = express();

app.use(express.static("public"));
app.use(bodyParser.urlencoded({extended: true}));

app.get("/", function( req ,res ){
	res.sendFile(__dirname + "/signup.html");
});

app.post("/", function(req,res) {
	var firstName = req.body.fname;
	var lastName = req.body.sname;
	var email = req.body.email;

	var data = {
		members: [
		{
			email_address: email,
			status: "subscribed",
			merge_fields: {
				FNAME: firstName,
				LNAME: lastName
			}
		}
		]
	};
	

	const jsonData = JSON.stringify(data);
	
	const url = "https://us10.api.mailchimp.com/3.0/lists/264397afef";

	const options = {
		method: "POST",
		auth: "jattu:34f9fc3c5e6f4734ccc178f6f60d42ee-us10"
	};

	const request = https.request( url, options, function (response) {
		console.log(response.statusCode);
		if( response.statusCode === 200 )
			res.sendFile(__dirname+"/success.html");
		else
			res.sendFile(__dirname+"/failure.html");
	});

	app.post("/failure",function(req,res) {
		res.redirect("/");
	});
	
	request.write(jsonData);
	request.end();

});


 


app.listen(process.env.PORT || 3000);

//API key
//34f9fc3c5e6f4734ccc178f6f60d42ee-us10

//List ID
//264397afef